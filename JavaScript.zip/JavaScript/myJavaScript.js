form = false;

window.onload=function(){
console.log(top.form);
	
	if(form){
		document.getElementById("spiel").href = "SpielReal.html";
	}

/*
-----------------------VARIABLEN--------------------------
*/

    var nachname=document.getElementById('nachname');
    var vorname=document.getElementById('vorname');
    var age=document.getElementById('age');
    var sub=document.getElementById('sub');
	var email=document.getElementById("mail");
	var dönername=document.getElementById('dönername');
	var döneradresse=document.getElementById("döneradresse");
	var dönerbezirk=document.getElementById('dönerbezirk');
	
if(nachname!==null){
		
   document.getElementById("formular")[0].addEventListener("submit", function(){checkForm()});
	
}
	
                      	
/*
-----------------------FUNKTIONEN--------------------------
*/

		
function notEmpty(field){
        console.log(field.value);
	
        if(field.value!==""){
			console.log("True")
            return true;}
        else{
            //alert(field);
			console.log("False");
            return false;
        }  
}
	
function checkForm(){
	
	//return false;
	var ret = ""; 
	var valid = true;
	var regexletter = new RegExp(/^[a-zA-Z]/);

	
	if(!regexletter.test(vorname.value)){
		ret = ret + "\nVorname";
		valid = false;
	}
	
	if(!regexletter.test(nachname.value)){
		ret = ret + "\nNachname";
		valid = false;
	}
	
	if(!notEmpty(age)){
		ret = ret + "\nAlter";
		valid = false;
	}
	
	if(!notEmpty(mail)){
		ret = ret + "\nE-Mail";
		valid = false;
	}
	
	if(!notEmpty(dönername)){
		ret = ret + "\nName des Dönerladens";
		valid = false;
	}
	
	if(!notEmpty(döneradresse)){
		ret = ret + "\nAdresse des Dönerladens";
	 	valid = false;

	}
	
	if(!notEmpty(dönerbezirk)){
		ret = ret + "\nBezirk des Dönerladens";
		valid = false;
	}
	
	if(!valid){
		
		ret = "Bitte gib uns noch folgende Daten: " + ret;
		alert(ret);
		
	}
	
	if(valid){
		form = true;
		document.getElementById("spiel").href = "SpielReal.html";
	}
	

	return valid;
}

}